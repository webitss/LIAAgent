interface AuthConfig {
    clientID: string;
    domain: string;
    callbackURL: string;
}

export const AUTH_CONFIG: AuthConfig = {
    clientID: '{CLIENT_ID}',
    domain: '{DOMAIN}',
    callbackURL: 'http://localhost:4204/menu'
};