import { Component, OnInit } from '@angular/core';
import {Router} from "@angular/router";
import {AppService} from "../app.service";

@Component({
    selector: 'app-products',
    template: `
      <div class="div"><img src="assets/pictures/bomb2.jpg"  (click)="this.goTo('Site')"/>
          <p>Site</p>
      </div>
      <div ><img src="assets/pictures/bang.jpg" (click)="this.goTo('Warnings')"/>
          <p>Warnings</p>
      </div>
      <div ><img src="assets/pictures/arrow.jpg" (click)="this.goTo('Application')"/>
          <p>Application</p>
      </div>
      <div ><img src="assets/pictures/childish.jpg"  (click)="this.goTo('FavoriteSales')"/>
          <p>FavoriteSales</p>
      </div>
      <div ><img src="assets/pictures/houses.jpg"  (click)="this.goTo('FaceBookCampain')"/>
          <p>FaceBookCampain</p>
      </div>
  
 `,
    styles: [
        `
          img{
          width: 50px;
          height:50px;
      }
      div{
          width: 50px;
          height:50px;  
    }
          .div
          {
              
            display:inline-block;
              vertical-align:middle;
              position: relative;
              left:200px;
              top: 50%;
              margin-top: 100px;
              /*float: left;*/
          }`
    ]
})
export class ProductsComponent implements OnInit {

    constructor(public router:Router,public service:AppService) { }

    ngOnInit() {
    }
    goTo(product:String)
    {
        /*this.service.post();*/
        this.service.changeCurrentProduct(product)
        this.router.navigate(['productDetails']);
    }
}