import {Component} from "@angular/core";

@Component({
  selector: 'home', 
  styles : [],
  template: `
      <div>home</div>
<div>
  
</div>
`})
export class HomeComponent { }