import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cart',
  template: `
    <p>
      cart works!
    </p>
  `,
  styles: []
})
export class CartComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
