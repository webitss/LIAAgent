import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customer',
  template: `
    <p>
      customer works!
    </p>
  `,
  styles: []
})
export class CustomerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
