import { Component, OnInit } from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {LiaService} from "../lia.service";

@Component({
    selector: 'app-galery',
    template: `
        <div>
            <img class="img" src="assets/pictures/arrow.jpg" (click)="this.changePicture(true)">
            <div class="myDiv"> <div ><img  class="slideRight-001" [src]=service.galery[i]></div></div>
            <img class="img2" src="assets/pictures/arrow.jpg" (click)="this.changePicture(false)" >

        </div>

    `,
    styles: [
        `
          .slideRight-001{
              width: 650px;
              height: 610px;
              border-color: slategray;
              border: groove;
              display:inline-block;
              vertical-align:middle;
              position: relative;
              left:250px;
              margin-top: 40px;
              animation-name: slideRight;
              -webkit-animation-name: slideRight;

             animation-duration: 1s;
              -webkit-animation-duration: 1s;

             animation-timing-function: ease-in-out;
              -webkit-animation-timing-function: ease-in-out;

             visibility: visible !important;
          }

         @keyframes slideRight {
              0% {transform: translateX(-150%);}
              100% {transform: translateX(0%);}
          }

         @-webkit-keyframes slideRight {
              0% {-webkit-transform: translateX(-150%);}
              100% {-webkit-transform: translateX(0%);}
          }
     .img
     {
              width: 50px;
              height:50px;
              display:inline-block;
              vertical-align:middle;
              position: absolute;
              right:100px;
              top: 30%;
              /*float: left;*/
      }
     .myDiv{
         /*width: 650px;
         height: 610px;
         border-color: slategray;
         border: groove;
         display:inline-block;
         vertical-align:middle;
         position: relative;
         left:250px;
         margin-top: 40px;*/
         /*top: 50%;*/
     }
     .imgDiv{
         width: 650px;
         height: 610px;  
    }
      .img2{
          width: 50px;
          height:50px;
          display:inline-block;
          vertical-align:middle;
          position: absolute;
          left:100px;
          top: 30%;
         /* position:absolute;
          left:50%;
          top:50%;
          width:50px;
          height:50px;
          display: block;
          margin-left: 50%;*/
      }`
    ]
})
export class GaleryComponent implements OnInit {
    i:number;
    constructor(public service: LiaService) {
        this.i=0;
        if (service.galery === undefined) {
            this.service.post("GetGaleryPictures");
            service.galery = service.temp;
        }
    }
   /* constructor( ) {


        this.i=0;

        //this.myPictures.push()
        this.myPictures.push("assets/pictures/bomb2.jpg");
        this.myPictures.push("assets/pictures/childish.jpg");
        this.myPictures.push("assets/pictures/houses.jpg");
        this.myPictures.push("assets/pictures/arrow.jpg");
    }*/
    myPictures:String[]=[];
    ngOnInit() {

    }
    changePicture(right:boolean)
    {
        if(right)
        {
            if(this.i<this.myPictures.length-1)
                this.i++;
        }
        else {
            if(this.i>0)
                this.i--;
        }
    }

}
//<img src="assets/pictures/"${this.myPictures[0]}/>
