/*
import {Component} from "@angular/core";
import {AuthService} from "./authentication.service";

@Component({
  selector: 'callback',
  styles : [],
  template: `
      <div>
          wowwwwwwwwwwwttsetst
      </div>
`})
export class CallbackComponent {
  constructor(public auth:AuthService)
  {
    auth.i++;
      console.log(auth.i);
  }

}*/
