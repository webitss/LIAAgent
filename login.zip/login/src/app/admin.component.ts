/*
import {Component} from "@angular/core";

@Component({
  selector: 'Admin', 
  styles : [],
  template: `
<div>
  sdfjkjsdfjk
</div>
`})
export class AdminComponent { }*/
