import {Component} from "@angular/core";
import {PackagesModel} from "./packages.model";
import {LiaService} from "../lia.service";
import {noUndefined} from "@angular/compiler/src/util";

@Component({
    selector: 'package3',
    styles: [`
        .bord {
            border: dotted;
            border: #efef0f;
            width: 200px;
            margin: 1px;
            padding: 1px;
            size: 200px;
            border: 5px solid red;
        }

    `],
    template: `
        <div>
            <table>
                <td *ngFor="let p of service.packages let i =index">
                    <div >
                        <package [package]="p" (click)="edit(i)" [routerLink]="p?.ProductId"></package>
                    </div>
                </td>
            </table>
        </div>
    `
})
export class Package3Component {


    constructor(public service: LiaService) {
        if (service.packages === undefined) {
            this.service.post("GetPackages");
            service.packages = service.temp;
        }
    }

    edit(i: number) {
        /*for (let j = 0; j < this.packages.length; j++)
            if (j != i)
                this.packages[j].isAny = false;*/
    }

}