import {Component, Input} from "@angular/core";
import {PackagesModel} from "./packages.model";


@Component({
    selector: 'package',
    styles: [
        `
            .bord {
                border: dotted;
                border: #efef0f;
                width: 200px;
                margin: 1px;
                padding: 1px;
                size: 200px;
                border: 5px solid red;
            }
        
        `
    ],
    template: `        
        <div class="bord">
            ProductName:   {{package?.ProductName}}<br>
            TicketCost:    {{package?.TicketCost}}<br>
            TicketsNum:    {{package?.TicketsNum}}<br>
            
        </div>
        
    `
})
export class PackageComponent {
    constructor() {
    }

    @Input() package: any;

}
