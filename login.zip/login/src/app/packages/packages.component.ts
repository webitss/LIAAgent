/*
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-packages',
  template: `
    <p>
      packages works!
    </p>
      <div class="back">
          <button routerLink="Package3"><-</button>
      </div> 
    <router-outlet></router-outlet>
 
  `,
  styles: [`
  .back{


      height: 85vh;
      background-size: 100vw 100vh;
      background-image: url("../../assets/package.png");
      background-repeat: no-repeat;
  }
  
  `]
})
export class PackagesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
*/
