/*
export class ListShell {
    Result:list
}

*/
